// Function to check if the user is using a mobile device
function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
}

// Function to show the popup for mobile users
function showPopup() {
    
    var popup = document.getElementById("popup");
   
    if (isMobileDevice()) {
        popup.classList.add("active");
       
        
    }

   
}

// Function to close the popup
function closePopup() {
    var popup = document.getElementById("popup");
    popup.classList.remove("active");
    

}

// Show the popup when the page loads
document.addEventListener("DOMContentLoaded", function() {
    showPopup();
   
});
// Function to show the popup for mobile users
function showPopup() {
    var popup = document.getElementById("popup");
    if (isMobileDevice()) {
        popup.classList.add("active");
        document.body.classList.add("popup-active"); // Add this line to disable scrolling
        var stickyMenu = document.getElementsByClassName("navbar-area");
        stickyMenu[0].style.display='none';
}

// Function to close the popup
function closePopup() {
    var popup = document.getElementById("popup");
    popup.classList.remove("active");
    document.body.classList.remove("popup-active"); // Add this line to enable scrolling
    
}
}
